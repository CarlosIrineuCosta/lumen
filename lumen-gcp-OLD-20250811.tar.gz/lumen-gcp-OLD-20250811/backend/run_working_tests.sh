pytest tests/unit/test_auth_middleware.py::TestAuthUser tests/unit/test_user_model.py::TestUserPydanticModels tests/unit/test_photo_model.py::TestPhotoPydanticModels --tb=short -q
